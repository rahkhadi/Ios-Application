//
//  ManagerScene.swift
//  MidtermSummer24
//
//  Created by Rahimullah Khadim hussain on 2024-07-06.
//

import UIKit

class ManagerScene: UIViewController {
    
    @IBOutlet weak var newProductName: UITextField!
    @IBOutlet weak var newProductPrice: UITextField!
    @IBOutlet weak var newProductShortName: UITextField!
    @IBOutlet weak var newProductImageName: UITextField!
    @IBOutlet weak var newProductStock: UITextField!
    @IBOutlet weak var stockView: UIView!
    @IBOutlet weak var purchasesView: UIView!
    
    var store: Store!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayCurrentStock()
    }
    
    @IBAction func addNewProduct(_ sender: UIButton) {
        guard let name = newProductName.text,
              let priceText = newProductPrice.text,
              let price = Double(priceText),
              let shortName = newProductShortName.text,
              let imageName = newProductImageName.text,
              let stockText = newProductStock.text,
              let stock = Int(stockText) else {
            return
        }
        
        let newDonut = Donut(
            title: name,
            price: price,
            shortName: shortName,
            imageName: imageName,
            availabilityCount: stock
        )
        
        store.donuts.append(newDonut)
        displayCurrentStock()
    }
    
    @IBAction func updateStock(_ sender: UIButton) {
        guard let name = newProductShortName.text,
                  let stockText = newProductStock.text,
                  let stock = Int(stockText) else {
                return
            }

            if let donutIndex = store.donuts.firstIndex(where: { $0.shortName == name }) {
                store.donuts[donutIndex].availabilityCount += stock
            }
            displayCurrentStock()
    }
    
    @IBAction func viewPurchases(_ sender: UIButton) {
        displayPurchases()
    }
    
    func displayCurrentStock() {
        guard let stockView = stockView else { return }
        for view in stockView.subviews {
            view.removeFromSuperview()
        }

        var yOffset: CGFloat = 10
        for donut in store.donuts {
            let label = UILabel(frame: CGRect(x: 10, y: yOffset, width: stockView.frame.width - 20, height: 30))
            label.text = "\(donut.title) - Stock: \(donut.availabilityCount)"
            stockView.addSubview(label)
            yOffset += 40
        }
    }

    func displayPurchases() {
        guard let purchasesView = purchasesView else { return }
        for view in purchasesView.subviews {
            view.removeFromSuperview()
        }

        var yOffset: CGFloat = 10
        let purchases = store.purchases.map { "\($0.quantity) \($0.donut.shortName) donut(s) for $\(String(format: "%.2f", $0.total))" }

        for purchase in purchases {
            let label = UILabel(frame: CGRect(x: 10, y: yOffset, width: purchasesView.frame.width - 20, height: 30))
            label.text = purchase
            purchasesView.addSubview(label)
            yOffset += 40
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
