//
//  ViewController.swift
//  MidtermSummer24
//
//  Created by Rahimullah Khadim hussain on 2024-07-06.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    @IBOutlet weak var donutNameLabel: UILabel!
    @IBOutlet weak var donutImageView: UIImageView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var donutPriceLabel: UILabel!
    
    let store = Store()
    var selectedDonut: Donut?
        
    override func viewDidLoad() {
            super.viewDidLoad()
            pickerView.dataSource = self
            pickerView.delegate = self
            selectedDonut = store.donuts.first
            updateProductDetails()
        }
        
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 2
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            if component == 0 {
                return store.donuts.count
            } else {
                return selectedDonut?.availabilityCount ?? 0
            }
        }
        
        func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
            if component == 0 {
                let donut = store.donuts[row]
                let view = UIView()
                let imageView = UIImageView(image: UIImage(named: donut.imageName))
                imageView.contentMode = .scaleAspectFit
                imageView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
                let label = UILabel()
                label.text = donut.description
                label.textAlignment = .center
                label.frame = CGRect(x: 110, y: 0, width: 150, height: 100)
                view.addSubview(imageView)
                view.addSubview(label)
                return view
            } else {
                let label = UILabel()
                label.text = "\(row + 1)"
                label.textAlignment = .center
                return label
            }
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            if component == 0 {
                selectedDonut = store.donuts[row]
                pickerView.reloadComponent(1)
                updateProductDetails()
            }
        }
        
        func updateProductDetails() {
            if let donut = selectedDonut {
                donutNameLabel.text = donut.title
                donutImageView.image = UIImage(named: donut.imageName)
                donutPriceLabel.text = "Price: $\(donut.price)"
            }
        }
        
    
    @IBAction func buyButtonPressed(_ sender: UIButton) {
        let selectedRow = pickerView.selectedRow(inComponent: 1)
        let quantity = selectedRow + 1
        if let donut = selectedDonut {
            let total = Double(quantity) * donut.price
            let purchase = (donut, quantity, total, Date())
            store.purchases.append(purchase)
            
            let alertController = UIAlertController(title: "Success", message: "You bought \(quantity) \(donut.shortName) donut(s) for $\(total). Thank you", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toManagerViewController" {
            if let managerVC = segue.destination as? ManagerViewController {
                managerVC.store = self.store
            }
        }
    }
    
    }
