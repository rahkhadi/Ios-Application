//
//  ManagerViewController.swift
//  MidtermSummer24
//
//  Created by Rahimullah Khadim hussain on 2024-07-06.
//

import Foundation

import UIKit

class ManagerViewController: UIViewController {
    
    
    @IBOutlet weak var passcodeTextField: UITextField!
    var store: Store!
    
    @IBAction func accessManagerMode(_ sender: UIButton) {
        let passcode = passcodeTextField.text ?? ""
        if passcode == "1234" {
            performSegue(withIdentifier: "toManagerScene", sender: self)
        } else {
            let alertController = UIAlertController(title: "Error", message: "Incorrect passcode", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
    }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if segue.identifier == "toManagerScene" {
                    if let managerSceneVC = segue.destination as? ManagerScene {
                        managerSceneVC.store = self.store
                    }
                }
            }
        }
